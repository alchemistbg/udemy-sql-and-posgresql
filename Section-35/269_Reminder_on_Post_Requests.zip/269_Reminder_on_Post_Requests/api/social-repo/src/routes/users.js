const express = require("express");

const router = express.Router();

const UserRepo = require('../repos/user-repo');

router.get('/users', async (req, res) => {
	const users = await UserRepo.find();

	res.send(users);
});

router.get('/users/:id', async (req, res) => {
	const { id } = req.params;

	const user = await UserRepo.findById(id);

	if (user[0]) {
		res.send(user);
	} else {
		res.sendStatus(404);
	}

});

router.post('/users', async (req, res) => {
	console.log(req.body);

	res.send(req.body);
});

router.put('/users', async (req, res) => {
 
});

router.delete('/users', async (req, res) => {

});

module.exports = router;