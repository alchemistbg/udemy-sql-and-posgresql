const request = require('supertest');
const appBuilder = require('../../app');
const UserRepo = require('../../repos/user-repo');
const pool = require('../../pool')

beforeAll(() => {
	return pool.connect({
		host: 'localhost',
		port: 5432,
		database: 'socialnetwork',
		user: "postgres",
		password: 'password for postges user' //SAME as windows password
	});
});

afterAll(() => {
	return pool.close();
});

it('create a user', async () => {
	const startUsersCount = await UserRepo.count();
	expect(startUsersCount).toEqual(0);

	await request(appBuilder())
		.post('/users')
		.send({ username: 'testuser', bio: 'test bio' })
		.expect(200);
	
	const endUsersCount = await UserRepo.count();
	expect(endUsersCount).toEqual(1);
});