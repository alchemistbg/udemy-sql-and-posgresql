const request = require('supertest');
const appBuilder = require('../../app');
const UserRepo = require('../../repos/user-repo');
const Context = require('../context')

let context;
beforeAll(async () => {
	context = await Context.build();
});

beforeEach(async () => {
	await context.reset();
});

afterAll(() => {
	return context.close()
});

it('create a user', async () => {
	const startUsersCount = await UserRepo.count();
	// expect(startUsersCount).toEqual(0);

	await request(appBuilder())
		.post('/users')
		.send({ username: 'testuser', bio: 'test bio' })
		.expect(200);
	
	const endUsersCount = await UserRepo.count();
	expect(endUsersCount - startUsersCount).toEqual(1);
});