const request = require('supertest');
const appBuilder = require('../../app');
const UserRepo = require('../../repos/user-repo');
const pool = require('../../pool');

const { randomBytes } = require('crypto');
const { default: migrate } = require('node-pg-migrate');
const format = require('pg-format');

beforeAll(async () => {
	// Randomly generating a role name to connect to PG as
	const roleName = 'a' + randomBytes(4).toString('hex');

	// Connect to PG as usual
	await pool.connect({
		host: 'localhost',
		port: 5432,
		database: 'socialnetwork-test',
		user: "postgres",
		password: 'password for postges user' //SAME as windows password
	});

	// Create a new role
	await pool.query(`
		CREATE ROLE ${roleName} WITH LOGIN PASSWORD '${roleName}';
	`);

	// Create a new schema with the same name
	await pool.query(`
		CREATE SCHEMA ${roleName} AUTHORIZATION ${roleName};
	`);

	// Disconnect entirely from PG
	await pool.close();

	// Run new migrations in the new schema
	await migrate({
		schema: roleName,
		direction: 'up',
		log: () => { },
		noLock: true,
		dir: 'migrations',
		databaseUrl: {
			host: 'localhost',
			port: 5432,
			database: 'socialnetwork-test',
			user: roleName,
			password: roleName
		}
	});

	// Connect to PG as newly created role
	await pool.connect({
		host: 'localhost',
		port: 5432,
		database: 'socialnetwork-test',
		user: roleName,
		password: roleName
	});

});

afterAll(() => {
	return pool.close();
});

it('create a user', async () => {
	const startUsersCount = await UserRepo.count();
	// expect(startUsersCount).toEqual(0);

	await request(appBuilder())
		.post('/users')
		.send({ username: 'testuser', bio: 'test bio' })
		.expect(200);
	
	const endUsersCount = await UserRepo.count();
	expect(endUsersCount - startUsersCount).toEqual(1);
});