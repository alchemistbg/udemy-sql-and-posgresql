const app = require('./src/app.js');
const pool = require('./src/pool');

pool.connect({
	host: 'localhost',
	port: 5432,
	database: 'socialnetwork',
	user: "postgres",
	password: 'password for postges user' //SAME as windows password
})
	.then(() => {
		app().listen(3001, () => {
			console.log('App listening on port 3001!');
		});
	}).catch((err) => {
		console.error(err)
});
