const pool = require('../pool');

const toCamelCase = require('./utils/to-camel-case');

class UserRepo{
	static async find() {
		// const result = await pool.query(`
		const { rows } = await pool.query(`
			SELECT * FROM users;
		`);
		console.log(rows)
		return toCamelCase(rows);
		
	}

	static async findById() {
		
	}

	static async insert() {

	}

	static async update() {

	}

	static async delete() {

	}
};

module.exports = UserRepo;