const express = require("express");

const router = express.Router();

const UserRepo = require('../repos/user-repo')

router.get('/users', async (req, res) => {
	const users = await UserRepo.find();
	
	res.send(users)
});

router.get('/users/:id', async (req, res) => {

});

router.post('/users', async (req, res) => {

});

router.put('/users', async (req, res) => {
 
});

router.delete('/users', async (req, res) => {

});

module.exports = router;